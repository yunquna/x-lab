(() => {
  "use strict";

  const state = {
    running: false,
    cancelled: false,
    results: [],
    panel: null,
    logEl: null,
    progressEl: null,
  };

  const CONFIG = {
    batchCodeRegex: /^PC\d+/i,
    waitPopupMs: 8000,
    stepDelayMs: 500,
    pageDelayMs: 1200,
  };

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function text(el) {
    return (el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function qsa(selector, root = document) {
    return Array.from(root.querySelectorAll(selector));
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return (
      rect.width > 0 &&
      rect.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      style.opacity !== "0"
    );
  }

  function log(msg) {
    console.log("[WMS Batch Extractor]", msg);
    if (!state.logEl) return;
    const div = document.createElement("div");
    div.textContent = `${new Date().toLocaleTimeString()}  ${msg}`;
    state.logEl.prepend(div);
  }

  function setProgress(msg) {
    if (state.progressEl) state.progressEl.textContent = msg;
  }

  function createButton(label, onClick, extraClass = "") {
    const btn = document.createElement("button");
    btn.className = `wbe-btn ${extraClass}`.trim();
    btn.textContent = label;
    btn.addEventListener("click", onClick);
    return btn;
  }

  function injectStyles() {
    if (document.getElementById("wbe-inline-style")) return;

    const style = document.createElement("style");
    style.id = "wbe-inline-style";
    style.textContent = `
      #wbe-panel {
        position: fixed;
        right: 16px;
        bottom: 16px;
        z-index: 999999;
        width: 380px;
        background: #ffffff;
        border: 1px solid #d9d9d9;
        border-radius: 12px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        padding: 12px;
        font-family: Arial, sans-serif;
        color: #111;
      }
      .wbe-title {
        font-size: 14px;
        font-weight: 700;
        margin-bottom: 8px;
        cursor: move;
        user-select: none;
      }
      .wbe-desc {
        font-size: 12px;
        color: #666;
        margin-bottom: 10px;
      }
      .wbe-progress {
        font-size: 12px;
        color: #333;
        margin-bottom: 10px;
        padding: 8px;
        background: #f7f7f7;
        border-radius: 8px;
      }
      .wbe-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 10px;
      }
      .wbe-btn {
        padding: 8px 12px;
        border-radius: 8px;
        border: 1px solid #1677ff;
        background: #1677ff;
        color: #fff;
        cursor: pointer;
        font-size: 12px;
      }
      .wbe-btn.danger {
        background: #ff4d4f;
        border-color: #ff4d4f;
      }
      .wbe-btn.success {
        background: #52c41a;
        border-color: #52c41a;
      }
      .wbe-btn.secondary {
        background: #722ed1;
        border-color: #722ed1;
      }
      .wbe-log {
        max-height: 260px;
        overflow: auto;
        font-size: 12px;
        background: #fafafa;
        border: 1px solid #eee;
        border-radius: 8px;
        padding: 8px;
      }
    `;
    document.head.appendChild(style);
  }

  function makePanelDraggable(panel, handle) {
    let isDragging = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;

    handle.addEventListener("mousedown", (e) => {
      if (e.button !== 0) return;

      const rect = panel.getBoundingClientRect();

      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      startLeft = rect.left;
      startTop = rect.top;

      panel.style.left = `${rect.left}px`;
      panel.style.top = `${rect.top}px`;
      panel.style.right = "auto";
      panel.style.bottom = "auto";

      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!isDragging) return;
      panel.style.left = `${startLeft + e.clientX - startX}px`;
      panel.style.top = `${startTop + e.clientY - startY}px`;
    });

    document.addEventListener("mouseup", () => {
      isDragging = false;
    });
  }

  function createPanel() {
    if (state.panel) return;

    const panel = document.createElement("div");
    panel.id = "wbe-panel";

    panel.innerHTML = `
      <div class="wbe-title">批次编码 → 小窗口全部信息</div>
      <div class="wbe-desc">抓取弹窗表格里的所有字段，并支持自动翻页。</div>
      <div class="wbe-progress">就绪</div>
      <div class="wbe-actions"></div>
      <div class="wbe-log"></div>
    `;

    const actions = panel.querySelector(".wbe-actions");

    actions.append(
      createButton("提取全部页", extractAllPages),
      createButton("提取当前页", extractCurrentPage),
      createButton("停止", () => {
        state.cancelled = true;
        log("已请求停止");
      }, "danger"),
      createButton("导出 CSV", () => exportCSV(state.results), "success"),
      createButton("复制结果", copyResults, "secondary")
    );

    document.body.appendChild(panel);

    makePanelDraggable(panel, panel.querySelector(".wbe-title"));

    state.panel = panel;
    state.logEl = panel.querySelector(".wbe-log");
    state.progressEl = panel.querySelector(".wbe-progress");
  }

  function safeClick(el) {
    if (!el) return;
    el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  }

  function getBatchRows() {
    return qsa("a")
      .filter(a => CONFIG.batchCodeRegex.test(text(a)))
      .map(a => ({
        batchCode: text(a),
        link: a
      }));
  }

  function findPopupTable() {
    return qsa("table")
      .filter(isVisible)
      .find(t => {
        const content = text(t);
        return (
          content.includes("托盘") &&
          content.includes("托重")
        );
      });
  }

  async function waitForPopupTable() {
    const start = Date.now();

    while (Date.now() - start < CONFIG.waitPopupMs) {
      const table = findPopupTable();
      if (table) return table;
      await sleep(200);
    }

    return null;
  }

  function parsePopupTable(table) {
    const headers = qsa("th", table).map(th => text(th));
    const rows = qsa("tr", table);

    let dataRow = rows.find(tr => qsa("td", tr).length > 0);
    const cells = dataRow ? qsa("td", dataRow).map(td => text(td)) : [];

    const result = {};

    headers.forEach((header, index) => {
      if (!header) return;
      result[header] = cells[index] || "";
    });

    if (!headers.length && cells.length) {
      cells.forEach((value, index) => {
        result[`字段${index + 1}`] = value;
      });
    }

    return result;
  }

  function getAllHeaders(rows) {
    const base = ["批次编码"];
    const extra = [];

    for (const row of rows) {
      Object.keys(row).forEach(key => {
        if (!base.includes(key) && !extra.includes(key)) {
          extra.push(key);
        }
      });
    }

    return [...base, ...extra.filter(h => h !== "批次编码")];
  }

  function exportCSV(rows) {
    if (!rows.length) {
      log("没有可导出的数据");
      return;
    }

    const headers = getAllHeaders(rows);
    const lines = [headers.join(",")];

    for (const row of rows) {
      lines.push(
        headers
          .map(h => `"${String(row[h] || "").replace(/"/g, '""')}"`)
          .join(",")
      );
    }

    const blob = new Blob(["\uFEFF" + lines.join("\n")], {
      type: "text/csv;charset=utf-8"
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = `batch_full_${Date.now()}.csv`;
    a.click();

    URL.revokeObjectURL(url);
  }

  async function copyResults() {
    if (!state.results.length) {
      log("没有可复制的数据");
      return;
    }

    const headers = getAllHeaders(state.results);
    const lines = [
      headers.join("\t"),
      ...state.results.map(row =>
        headers.map(h => row[h] || "").join("\t")
      )
    ];

    await navigator.clipboard.writeText(lines.join("\n"));
    log("已复制结果");
  }

  async function extractCurrentPage(options = {}) {
    const append = options.append === true;

    if (state.running && !append) return;

    if (!append) {
      state.running = true;
      state.cancelled = false;
      state.results = [];
    }

    const rows = getBatchRows();
    log(`当前页发现 ${rows.length} 条批次`);

    for (let i = 0; i < rows.length; i++) {
      if (state.cancelled) break;

      const item = rows[i];
      setProgress(`当前页处理中 ${i + 1}/${rows.length}`);

      try {
        safeClick(item.link);
        await sleep(CONFIG.stepDelayMs);

        const table = await waitForPopupTable();

        if (!table) {
          log(`未找到弹窗表格: ${item.batchCode}`);
          continue;
        }

        const popupData = parsePopupTable(table);

        state.results.push({
          "批次编码": item.batchCode,
          ...popupData
        });

        log(`成功: ${item.batchCode}`);

      } catch (e) {
        log(`失败: ${item.batchCode}`);
      }
    }

    if (!append) {
      setProgress(`当前页完成，共提取 ${state.results.length} 条`);
      state.running = false;
    }
  }

  function getNextPageButton() {
    const candidates = qsa("button, li, a").filter(isVisible);

    return candidates.find(el => {
      const t = text(el);
      const cls = String(el.className || "").toLowerCase();

      const looksLikeNext =
        t === "下一页" ||
        t === ">" ||
        t === "›" ||
        cls.includes("next");

      const disabled =
        el.disabled ||
        cls.includes("disabled") ||
        el.getAttribute("aria-disabled") === "true";

      return looksLikeNext && !disabled;
    });
  }

  async function waitForPageChanged(oldFirstBatch) {
    const start = Date.now();

    while (Date.now() - start < 10000) {
      const rows = getBatchRows();
      const newFirstBatch = rows[0]?.batchCode;

      if (newFirstBatch && newFirstBatch !== oldFirstBatch) {
        return true;
      }

      await sleep(300);
    }

    return false;
  }

  async function extractAllPages() {
    if (state.running) return;

    state.running = true;
    state.cancelled = false;
    state.results = [];

    let page = 1;

    while (!state.cancelled) {
      const rowsBefore = getBatchRows();
      const oldFirstBatch = rowsBefore[0]?.batchCode || "";

      setProgress(`正在提取第 ${page} 页`);
      log(`开始提取第 ${page} 页`);

      await extractCurrentPage({ append: true });

      if (state.cancelled) break;

      const nextBtn = getNextPageButton();

      if (!nextBtn) {
        log("已到最后一页");
        break;
      }

      log("点击下一页");
      safeClick(nextBtn);

      await sleep(CONFIG.pageDelayMs);
      await waitForPageChanged(oldFirstBatch);

      page++;
    }

    setProgress(`全部完成，共提取 ${state.results.length} 条`);
    state.running = false;
  }

  function init() {
    injectStyles();
    createPanel();
  }

  init();
})();